﻿namespace FSH.Framework.Shared.Constants;

public static class ClaimConstants
{
    public const string Tenant = "tenant";
    public const string Fullname = "fullName";
    public const string Permission = "permission";
    public const string ImageUrl = "image_url";
    public const string IpAddress = "ipAddress";
    public const string Expiration = "exp";

    public const string ActorSubject = "act_sub";
    public const string ActorTenant = "act_tenant";
}